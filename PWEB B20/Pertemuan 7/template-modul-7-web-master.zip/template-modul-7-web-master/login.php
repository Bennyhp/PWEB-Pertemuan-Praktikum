<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Login</title>
</head>
<body>
    <div class="container login">
        <div class="logo">
            <img src="img/unmul.png" alt="logo unmul" width="70%">
        </div>
        <div class="form-login">
            <h3>Login</h3>
            <form action="" method="post">
                <input type="text" name="" placeholder="email atau username" class="input">
                <input type="password" name="" placeholder="password" class="input">

                <input type="submit" name="" value="Login" class="submit"><br><br>
            </form>

            <p>Belum punya akun?
                <a href="">Register</a>
            </p>
        </div>
    </div>
</body>
</html>